#include "Aufgabe1a_List.h"
List::List()
{
	head = new Node;
	tail = new Node;
	_size = 0;
	temp = false;
	head->next = tail;
	tail->prev = head;
}
List::~List()
{
	while (head != tail)
	{
		head = head->next;
		delete head->prev;
	}
	delete tail;
}
void List::InsertFront(int key)
{
	Node *neu = new Node; 
	neu->key = key;
	_size++;
	
	neu->prev = head;
	neu->next = head->next;
	neu->next->prev = neu; 
	head->next = neu;
}
void List::InsertBack(int key)
{
	Node *neu = new Node;
	neu->key = key;
	_size++;

	neu->next = tail;
	neu->prev = tail->prev;
	neu->prev->next = neu;
	tail->prev = neu;
}
bool List::getFront(int & key)
{
	if (_size == 0)
	{
		return false;
	}
	else
	{
		key = head->next->key;
		Node *ptr = head->next;  //Zwischenspeicher damit der zu l�schende Node nicht verloren geht
		head->next = head->next->next; //head mit Nachfolger des zu l�schenden Elemtenes verbinden
		ptr->next->prev = head;
		delete ptr;
		_size--;
		return true;
		
	}
}
bool List::getBack(int & key)
{
	Node *ptr = tail;  //Zwischenspeicher damit der zu l�schende Node nicht verloren geht
	if (ptr->prev != head)
	{
		key = tail->prev->key;
		ptr = ptr->prev;
		tail->prev = tail->prev->prev; //tail mit vorgaenger des zu l�schenden Elementes verbinden
		tail->prev->next = tail;
		delete ptr;
		_size--;
		return true;
	}
	else
	{
	return false;
	}
}
bool List::del(int key)
{
	Node *ptr = head;
	while (ptr != tail)
	{
		if (ptr->key == key)
		{
			ptr->next->prev = ptr->prev;
			ptr->prev->next = ptr->next;
			delete ptr;
			return true;
		}
		else
		{
			ptr = ptr->next;
		}
	}
	return false;
}
bool List::search(int key)
{
	Node *ptr = head; 
	while (ptr != tail)
	{
		if (ptr->key == key)
		{
			return true;
		}
		else
		{
			ptr = ptr->next;
		}
	}
	return false;
}
bool List::swap(int key1, int key2)
{	//Ersten Key finden, zweiten key finden 
	Node *ptr = head, *key1ptr = nullptr, *key2ptr = nullptr;
	for(int i = 0; ptr->next != tail; i++)
	{
		if (ptr->key == key1)
			key1ptr = ptr;
		if (ptr->key == key2)
			key2ptr = ptr;
		if (key1ptr != 0 && key2ptr != 0)
			break;
		ptr = ptr->next;
	}
	//Falls ein Key nicht gefunden werden konnte
	if (key1ptr == nullptr || key2ptr == nullptr)
		return false;
	//Falls die Keys identisch sind -> Kein Tausch n�tig
	if (key1ptr == key2ptr)
		return true;

	if (key1ptr->next == key2ptr)
	{
		Node *ptr3 = key1ptr;
		
		key1ptr->prev->next = key2ptr;
		key1ptr->next = key2ptr->next;
		key1ptr->prev = key2ptr;
		key1ptr->key = key2ptr->key;

		key2ptr->next->prev = ptr3;
		key2ptr->next = ptr3;
		key2ptr->key = ptr3->key;
		key2ptr->prev = ptr3->prev;
		return true;
	}
	//Swap von Key1- und Key2-Knoten:	
	Node *ptr2_prev = key2ptr->prev, *ptr2_next = key2ptr->next; //Hilfspointer
	
	key1ptr->prev->next = key2ptr;
	key1ptr->next->prev = key2ptr;

	key2ptr->prev->next = key1ptr;
	key2ptr->next->prev = key1ptr;

	key2ptr->prev = key1ptr->prev;
	key2ptr->next = key1ptr->next;

	key1ptr->prev = ptr2_prev;
	key1ptr->next = ptr2_next;
	return true;
}
int List::size(void)
{
	return _size;
}
bool List::test(void)
{
	Node *ptr = head;
	while (ptr != tail)
	{
		ptr = ptr->next;
	}
	while (ptr != head)
	{
		ptr = ptr->prev;
	}
	return true;
}

void List::format(const std::string & start, const std::string & zwischen, const std::string & ende)
{
	_form.start = start;
	_form.zwischen = zwischen;
	_form.ende = ende;
}

List & List::operator = (const List & _List)
{
	// in dem Objekt _List sind die Knoten enthalten, die Kopiert werden sollen.
	// Kopiert wird in das Objekt "this"
	if (this == &_List) return *this;	//  !! keine Aktion notwendig
	Node * tmp_node;
	if (_size)
	{
		Node * tmp_del;
		tmp_node = head->next;
		while (tmp_node != tail)		// Alle eventuell vorhandenen Knoten in this l�schen
		{
			tmp_del = tmp_node;
			tmp_node = tmp_node->next;
			delete tmp_del;
		}
		_size = 0;
		head->next = tail;
		tail->prev = head;
	}
	tmp_node = _List.head->next;
	while (tmp_node != _List.tail)
	{
		InsertBack(tmp_node->key);
		tmp_node = tmp_node->next;
	}
	if (_List.temp) delete & _List;		// ist die �bergebene Liste eine tempor�re Liste? -> aus Operator +
	return *this;
}

List & List::operator = (const List * _List)
{
	// in dem Objekt _List sind die Knoten enthalten, die Kopiert werden sollen.
	// Kopiert wird in das Objekt "this"
	if (this == _List) return *this;	//  !! keine Aktion notwendig
	Node * tmp_node;
	if (_size)
	{
		Node * tmp_del;
		tmp_node = head->next;
		while (tmp_node != tail)		// Alle eventuell vorhandenen Knoten in this l�schen
		{
			tmp_del = tmp_node;
			tmp_node = tmp_node->next;
			delete tmp_del;
		}
		_size = 0;
		head->next = tail;
		tail->prev = head;
	}
	tmp_node = _List->head->next;
	while (tmp_node != _List->tail)
	{
		InsertBack(tmp_node->key);
		tmp_node = tmp_node->next;
	}
	if (_List->temp) delete _List;		// ist die �bergebene Liste eine tempor�re Liste? -> aus Operator +
	return *this;
}

List & List::operator + (const List & List_Append)
{
	Node * tmp_node;
	List * tmp;
	if (temp) {								// this ist eine tempor�re Liste und kann ver�ndert werden
		tmp = this;
	}
	else {
		tmp = new List;						// this ist keine tempor�re Liste -> Kopie erzeugen
		tmp->temp = true;					// Merker setzten, dass es sich um eine tempor�re Liste handelt
		tmp_node = head->next;
		while (tmp_node != tail) {
			tmp->InsertBack(tmp_node->key);
			tmp_node = tmp_node->next;
		}
	}
	if (List_Append._size) {				// anh�ngen der �bergebenen Liste an tmp
		tmp_node = List_Append.head->next;
		while (tmp_node != List_Append.tail) {
			tmp->InsertBack(tmp_node->key);
			tmp_node = tmp_node->next;
		}
	}
	if (List_Append.temp) delete & List_Append;		// wurde eine tempor�re Liste �bergeben, dann wird diese gel�scht							// 
	return *tmp;
}

List & List::operator + (const List * List_Append)
{
	Node * tmp_node;
	List * tmp;
	if (temp) {								// this ist eine tempor�re Liste und kann ver�ndert werden
		tmp = this;
	}
	else {
		tmp = new List;						// this ist keine tempor�re Liste -> Kopie erzeugen
		tmp->temp = true;					// Merker setzten, dass es sich um eine tempor�re Liste handelt
		tmp_node = head->next;
		while (tmp_node != tail) {
			tmp->InsertBack(tmp_node->key);
			tmp_node = tmp_node->next;
		}
	}
	if (List_Append->_size) {				// anh�ngen der �bergebenen Liste an tmp
		tmp_node = List_Append->head->next;
		while (tmp_node != List_Append->tail) {
			tmp->InsertBack(tmp_node->key);
			tmp_node = tmp_node->next;
		}
	}
	if (List_Append->temp) delete List_Append;		// wurde eine tempor�re Liste �bergeben, dann wird diese gel�scht							// 
	return *tmp;
}

std::ostream & operator<<(std::ostream  & stream, List const & Liste)
{
	stream << Liste._form.start;
	for (Node * tmp = Liste.head->next; tmp != Liste.tail; tmp = tmp->next)
		stream << tmp->key << (tmp->next == Liste.tail ? Liste._form.ende : Liste._form.zwischen);
	if (Liste.temp) delete & Liste;			// wurde eine tempor�re Liste �bergeben, dann wird diese gel�scht
	return stream;
}

std::ostream & operator << (std::ostream & stream, List const * Liste)
{
	stream << Liste->_form.start;
	for (Node * tmp = Liste->head->next; tmp != Liste->tail; tmp = tmp->next)
		stream << tmp->key << (tmp->next == Liste->tail ? Liste->_form.ende : Liste->_form.zwischen);
	if (Liste->temp) delete Liste;			// wurde eine tempor�re Liste �bergeben, dann wird diese gel�scht
	return stream;
}